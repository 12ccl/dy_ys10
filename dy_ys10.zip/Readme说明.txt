说明：
1、该配置包适用于大圣软件（旧版和新版），ifw_block_app_link.xml为核心，包含了315个常用应用的禁用规则，
该规则主要禁用所有消息推送组件及后台服务，关断部分关联启动，有部分程序也禁用了hotplug热修补功能，
尽量保证所有软件功能正常。
2、大圣规则中system_hosts规则有两个订阅链接但不会自动导入，需要手动添加。
https://cdn.jsdelivr.net/gh/neoFelhz/neohosts@gh-pages/127.0.0.1/basic/hosts
https://gitlab.com/jdlingyu/ext_rules/raw/main/hosts/hosts
3、该规则我目前自用，如果遇到了其他问题可以反馈。规则不经常更新，大概半年到一年更新一次。
作者：TG：叶红鱼 时间：2024-1-7
